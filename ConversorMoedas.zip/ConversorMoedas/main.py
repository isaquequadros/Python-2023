from convert_currency import ConvertCurrency

api_key = "dea67470959faa0bad84"
conv_curr = ConvertCurrency(api_key)
print(conv_curr.transfor_Currency("USD", 20, "BRL"))